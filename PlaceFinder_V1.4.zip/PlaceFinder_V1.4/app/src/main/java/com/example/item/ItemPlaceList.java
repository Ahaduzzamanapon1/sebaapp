package com.example.item;

public class ItemPlaceList {
   
	private String  PlaceId;
	private String  PlaceCatId;
 	private String  PlaceName;
	private String  PlaceImage;
	private String  PlaceVideo;
	private String  PlaceDescription;
	private String  PlaceLatitude;
	private String  PlaceLongitude;
	private String  PlaceAddress;
	private String  PlacePhone;
	private String  PlaceWebsite;
	private String  PlaceEmail;
	private String  PlaceRateAvg;
	private String  PlaceRateTotal;
	private String  PlaceDistance;

	public String getPlaceDistance() {
		return PlaceDistance;
	}

	public void setPlaceDistance(String placeDistance) {
		PlaceDistance = placeDistance;
	}

	public String getPlaceId() {
		return PlaceId;
	}

	public void setPlaceId(String placeId) {
		PlaceId = placeId;
	}

	public String getPlaceCatId() {
		return PlaceCatId;
	}

	public void setPlaceCatId(String placeCatId) {
		PlaceCatId = placeCatId;
	}

	public String getPlaceName() {
		return PlaceName;
	}

	public void setPlaceName(String placeName) {
		PlaceName = placeName;
	}

	public String getPlaceImage() {
		return PlaceImage;
	}

	public void setPlaceImage(String placeImage) {
		PlaceImage = placeImage;
	}

	public String getPlaceVideo() {
		return PlaceVideo;
	}

	public void setPlaceVideo(String placeVideo) {
		PlaceVideo = placeVideo;
	}

	public String getPlaceDescription() {
		return PlaceDescription;
	}

	public void setPlaceDescription(String placeDescription) {
		PlaceDescription = placeDescription;
	}

	public String getPlaceLatitude() {
		return PlaceLatitude;
	}

	public void setPlaceLatitude(String placeLatitude) {
		PlaceLatitude = placeLatitude;
	}

	public String getPlaceLongitude() {
		return PlaceLongitude;
	}

	public void setPlaceLongitude(String placeLongitude) {
		PlaceLongitude = placeLongitude;
	}

	public String getPlaceAddress() {
		return PlaceAddress;
	}

	public void setPlaceAddress(String placeAddress) {
		PlaceAddress = placeAddress;
	}

	public String getPlacePhone() {
		return PlacePhone;
	}

	public void setPlacePhone(String placePhone) {
		PlacePhone = placePhone;
	}

	public String getPlaceWebsite() {
		return PlaceWebsite;
	}

	public void setPlaceWebsite(String placeWebsite) {
		PlaceWebsite = placeWebsite;
	}

	public String getPlaceEmail() {
		return PlaceEmail;
	}

	public void setPlaceEmail(String placeEmail) {
		PlaceEmail = placeEmail;
	}

	public String getPlaceRateAvg() {
		return PlaceRateAvg;
	}

	public void setPlaceRateAvg(String placeRateAvg) {
		PlaceRateAvg = placeRateAvg;
	}

	public String getPlaceRateTotal() {
		return PlaceRateTotal;
	}

	public void setPlaceRateTotal(String placeRateTotal) {
		PlaceRateTotal = placeRateTotal;
	}
}

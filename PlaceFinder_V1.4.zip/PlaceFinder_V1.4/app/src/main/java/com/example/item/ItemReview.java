package com.example.item;


public class ItemReview {

    private String ReviewName;
    private String ReviewRate;
    private String ReviewMessage;

    public String getReviewName() {
        return ReviewName;
    }

    public void setReviewName(String reviewName) {
        ReviewName = reviewName;
    }

    public String getReviewRate() {
        return ReviewRate;
    }

    public void setReviewRate(String reviewRate) {
        ReviewRate = reviewRate;
    }

    public String getReviewMessage() {
        return ReviewMessage;
    }

    public void setReviewMessage(String reviewMessage) {
        ReviewMessage = reviewMessage;
    }


}
